(()=>{var e={};e.id=1565,e.ids=[1565],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},71396:e=>{"use strict";e.exports=require("undici")},84770:e=>{"use strict";e.exports=require("crypto")},80665:e=>{"use strict";e.exports=require("dns")},17702:e=>{"use strict";e.exports=require("events")},92048:e=>{"use strict";e.exports=require("fs")},32615:e=>{"use strict";e.exports=require("http")},32694:e=>{"use strict";e.exports=require("http2")},98216:e=>{"use strict";e.exports=require("net")},19801:e=>{"use strict";e.exports=require("os")},55315:e=>{"use strict";e.exports=require("path")},35816:e=>{"use strict";e.exports=require("process")},76162:e=>{"use strict";e.exports=require("stream")},82452:e=>{"use strict";e.exports=require("tls")},17360:e=>{"use strict";e.exports=require("url")},21764:e=>{"use strict";e.exports=require("util")},71568:e=>{"use strict";e.exports=require("zlib")},46665:(e,i,a)=>{"use strict";a.r(i),a.d(i,{GlobalError:()=>t.a,__next_app__:()=>o,originalPathname:()=>m,pages:()=>x,routeModule:()=>u,tree:()=>d}),a(56826),a(13215),a(26083),a(69961);var l=a(23191),r=a(88716),s=a(37922),t=a.n(s),n=a(95231),c={};for(let e in n)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(c[e]=()=>n[e]);a.d(i,c);let d=["",{children:["cart",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,56826)),"C:\\Users\\aslan\\Desktop\\eticaret - Kopya\\app\\cart\\page.tsx"]}]},{metadata:{icon:[async e=>(await Promise.resolve().then(a.bind(a,4998))).default(e)],apple:[async e=>(await Promise.resolve().then(a.bind(a,53226))).default(e)],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(a.bind(a,13215)),"C:\\Users\\aslan\\Desktop\\eticaret - Kopya\\app\\layout.tsx"],error:[()=>Promise.resolve().then(a.bind(a,26083)),"C:\\Users\\aslan\\Desktop\\eticaret - Kopya\\app\\error.tsx"],"not-found":[()=>Promise.resolve().then(a.bind(a,69961)),"C:\\Users\\aslan\\Desktop\\eticaret - Kopya\\app\\not-found.tsx"],metadata:{icon:[async e=>(await Promise.resolve().then(a.bind(a,4998))).default(e)],apple:[async e=>(await Promise.resolve().then(a.bind(a,53226))).default(e)],openGraph:[],twitter:[],manifest:void 0}}],x=["C:\\Users\\aslan\\Desktop\\eticaret - Kopya\\app\\cart\\page.tsx"],m="/cart/page",o={require:a,loadChunk:()=>Promise.resolve()},u=new l.AppPageRouteModule({definition:{kind:r.x.APP_PAGE,page:"/cart/page",pathname:"/cart",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},10421:(e,i,a)=>{Promise.resolve().then(a.bind(a,68360))},68360:(e,i,a)=>{"use strict";a.r(i),a.d(i,{default:()=>R});var l=a(10326),r=a(17577),s=a(90434),t=a(46226),n=a(33071),c=a(90772),d=a(567),x=a(68483),m=a(54432),o=a(45842),u=a(55676),f=a(40914),p=a(48705),k=a(86333),h=a(98091),y=a(11019),v=a(83855),g=a(28916),b=a(90072),N=a(38001),z=a(1331),j=a(68664),w=a(43273);let K=(0,a(76557).Z)("Tag",[["path",{d:"M12 2H2v10l9.29 9.29c.94.94 2.48.94 3.42 0l6.58-6.58c.94-.94.94-2.48 0-3.42L12 2Z",key:"14b2ls"}],["path",{d:"M7 7h.01",key:"7u93v4"}]]);var S=a(18019),A=a(58038),E=a(6162),L=a(15445);function R(){let e=(0,E.T_)("cart"),i=(0,E.T_)("home"),a=(0,E.T_)("header"),R=(0,N.u)(e=>e.currency),{rates:C}=(0,z.h)(),T=e=>(0,b.uM)(e,R,C?.rates??null),{items:M,removeItem:Z,updateQuantity:P,clearCart:V,getTotalPrice:I,getTotalItems:D}=(0,u.x)(),{isAuthenticated:B}=(0,j.t)(),[G,U]=(0,r.useState)(""),[q,_]=(0,r.useState)(0),[H,Y]=(0,r.useState)(""),[O,F]=(0,r.useState)(!1),[W,$]=(0,r.useState)(!1),[X,Q]=(0,r.useState)(!1),[J,ee]=(0,r.useState)(null),ei=I(),ea=.2*ei,el=ei>3e3?0:50;return 0===M.length?l.jsx(f.ClassicPageShell,{breadcrumbs:[{label:e("title")}],title:e("emptyTitle"),description:e("emptyDesc"),children:(0,l.jsxs)("div",{className:"max-w-lg mx-auto text-center py-12",children:[l.jsx("div",{className:"w-24 h-24 rounded-2xl bg-white border border-slate-200 flex items-center justify-center mx-auto mb-8 shadow-sm",children:l.jsx(p.Z,{className:"w-12 h-12 text-slate-400"})}),(0,l.jsxs)("p",{className:"text-slate-600 mb-6 leading-relaxed",children:[e("browseAndContact")," ",l.jsx(s.default,{href:"/contact",className:"text-slate-800 font-semibold hover:underline",children:i("contactUs")}),"."]}),l.jsx(c.z,{asChild:!0,size:"lg",className:"rounded-xl min-h-[48px] w-full sm:w-auto touch-manipulation bg-slate-800 hover:bg-slate-700 text-white",children:(0,l.jsxs)(s.default,{href:"/products",className:"flex items-center justify-center gap-2",children:[l.jsx(k.Z,{className:"w-5 h-5"}),e("goToProducts")]})})]})}):(0,l.jsxs)(f.ClassicPageShell,{breadcrumbs:[{label:e("title")}],title:e("cartTitle"),description:`${D()} ${e("itemsCount")}`,children:[(0,l.jsxs)("div",{className:"grid grid-cols-1 lg:grid-cols-3 gap-5 sm:gap-6 md:gap-8 pb-safe min-w-0 max-w-full",children:[(0,l.jsxs)("div",{className:"lg:col-span-2 space-y-4 min-w-0",children:[(0,l.jsxs)(n.Zb,{className:"bg-white rounded-2xl border border-slate-200 shadow-sm",children:[l.jsx(n.Ol,{children:(0,l.jsxs)("div",{className:"flex items-center justify-between",children:[(0,l.jsxs)(n.ll,{children:[e("myCart")," (",D()," ",e("itemsCount"),")"]}),(0,l.jsxs)(c.z,{variant:"ghost",size:"sm",onClick:V,className:"text-destructive hover:text-destructive/90",children:[l.jsx(h.Z,{className:"w-4 h-4 mr-2"}),e("clearCart")]})]})}),l.jsx(n.aY,{className:"space-y-4",children:M.map(e=>(0,l.jsxs)("div",{className:"flex flex-col sm:flex-row gap-3 sm:gap-4 pb-4 border-b last:border-0",children:[l.jsx("div",{className:"w-full sm:w-24 h-40 sm:h-24 bg-muted rounded-xl flex items-center justify-center flex-shrink-0 overflow-hidden",children:e.image?l.jsx(t.default,{src:e.image,alt:e.name||"\xdcr\xfcn",width:96,height:96,className:"rounded-xl object-cover w-full h-full",onError:e=>{e.currentTarget.style.display="none"}}):l.jsx(p.Z,{className:"w-12 h-12 text-slate-400"})}),(0,l.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,l.jsxs)("div",{className:"flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4",children:[(0,l.jsxs)("div",{className:"flex-1",children:[l.jsx("h3",{className:"font-semibold text-slate-900 mb-1 text-base sm:text-lg",children:e.name||"\xdcr\xfcn"}),e.description&&l.jsx("p",{className:"text-sm text-slate-600 line-clamp-2 mb-2",children:e.description}),(0,l.jsxs)("div",{className:"flex flex-wrap gap-2",children:[e.category&&l.jsx(d.C,{variant:"secondary",className:"text-xs",children:(0,L.EQ)(e.category)?a((0,L.EQ)(e.category)):e.category}),e.isCustom&&l.jsx(d.C,{className:"text-xs bg-slate-800 text-white",children:"\xd6zel Konfig\xfcrasyon"})]})]}),(0,l.jsxs)("div",{className:"text-left sm:text-right w-full sm:w-auto",children:[l.jsx("div",{className:"font-bold text-slate-900 mb-1 text-lg sm:text-xl",children:T(e.price*e.quantity)}),(0,l.jsxs)("div",{className:"text-sm text-slate-600",children:[T(e.price)," / adet"]})]})]}),(0,l.jsxs)("div",{className:"flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3",children:[(0,l.jsxs)("div",{className:"flex items-center gap-2",children:[l.jsx(c.z,{variant:"outline",size:"sm",className:"h-11 w-11 sm:h-9 sm:w-9 p-0 touch-manipulation rounded-xl",onClick:()=>P(e.id,e.quantity-1),"aria-label":"Miktarı azalt",children:l.jsx(y.Z,{className:"w-5 h-5 sm:w-4 sm:h-4"})}),l.jsx(m.I,{type:"number",value:e.quantity,onChange:i=>{let a=parseInt(i.target.value)||1;P(e.id,a)},className:"w-24 sm:w-20 text-center h-11 sm:h-9 text-base sm:text-sm rounded-xl",min:"1"}),l.jsx(c.z,{variant:"outline",size:"sm",className:"h-11 w-11 sm:h-9 sm:w-9 p-0 touch-manipulation rounded-xl",onClick:()=>P(e.id,e.quantity+1),"aria-label":"Miktarı artır",children:l.jsx(v.Z,{className:"w-5 h-5 sm:w-4 sm:h-4"})})]}),(0,l.jsxs)(c.z,{variant:"ghost",size:"sm",onClick:()=>Z(e.id),className:"text-destructive hover:text-destructive/90 w-full sm:w-auto h-11 sm:h-9 touch-manipulation",children:[l.jsx(h.Z,{className:"w-5 h-5 sm:w-4 sm:h-4 mr-2"}),"Kaldır"]})]})]})]},e.id))})]}),l.jsx(c.z,{asChild:!0,variant:"outline",className:"w-full rounded-xl min-h-[48px] touch-manipulation",children:(0,l.jsxs)(s.default,{href:"/products",className:"flex items-center justify-center gap-2",children:[l.jsx(k.Z,{className:"w-4 h-4"}),"Alışverişe Devam Et"]})})]}),l.jsx("div",{className:"lg:col-span-1",children:(0,l.jsxs)(n.Zb,{className:"rounded-2xl border border-slate-200 bg-white shadow-sm lg:sticky lg:top-24",children:[l.jsx(n.Ol,{children:l.jsx(n.ll,{children:"Sipariş \xd6zeti"})}),(0,l.jsxs)(n.aY,{className:"space-y-4",children:[(0,l.jsxs)("div",{className:"space-y-2",children:[(0,l.jsxs)("div",{className:"flex justify-between text-sm",children:[l.jsx("span",{className:"text-slate-600",children:"Ara Toplam"}),l.jsx("span",{className:"font-medium",children:T(ei)})]}),(0,l.jsxs)("div",{className:"flex justify-between text-sm",children:[l.jsx("span",{className:"text-slate-600",children:"KDV (%20)"}),l.jsx("span",{className:"font-medium",children:T(ea)})]}),(0,l.jsxs)("div",{className:"flex justify-between text-sm",children:[l.jsx("span",{className:"text-slate-600",children:"Kargo"}),l.jsx("span",{className:"font-medium",children:0===el?l.jsx("span",{className:"text-green-600",children:"\xdccretsiz"}):T(el)})]}),ei<3e3&&(0,l.jsxs)("div",{className:"text-xs text-slate-600 mt-1",children:[T(3e3-ei)," daha alışveriş yapın, kargo \xfccretsiz olsun!"]})]}),l.jsx(x.Z,{}),q>0&&(0,l.jsxs)("div",{className:"flex justify-between text-sm text-green-600",children:[l.jsx("span",{children:"İndirim"}),(0,l.jsxs)("span",{className:"font-medium",children:["-",T(q)]})]}),(0,l.jsxs)("div",{className:"flex justify-between font-bold text-lg",children:[l.jsx("span",{children:"Toplam"}),l.jsx("span",{className:"text-slate-900 font-bold",children:T(ei+ea+el-q)})]}),(0,l.jsxs)("div",{className:"pt-4 border-t",children:[l.jsx(o._,{htmlFor:"coupon",className:"text-sm font-medium mb-2 block",children:"Kupon Kodu"}),(0,l.jsxs)("div",{className:"flex gap-2",children:[l.jsx(m.I,{id:"coupon",placeholder:"Kupon kodunuzu girin",value:G,onChange:e=>{U(e.target.value),Y("")},className:"flex-1 rounded-xl"}),l.jsx(c.z,{type:"button",variant:"outline",className:"rounded-xl min-h-[44px] min-w-[44px] touch-manipulation shrink-0",onClick:async()=>{if(G.trim()){Y("");try{let e=await fetch("/api/coupons/validate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:G.trim(),subtotal:ei})}),i=await e.json();i.valid&&null!=i.discount?(_(i.discount),Y("")):(_(0),Y(i.message||"Ge\xe7ersiz kupon kodu"))}catch{_(0),Y("Kupon kontrol edilemedi.")}}},children:l.jsx(K,{className:"w-4 h-4"})})]}),H&&l.jsx("p",{className:"text-xs text-destructive mt-1",children:H}),q>0&&l.jsx("p",{className:"text-xs text-green-600 mt-1",children:"Kupon uygulandı!"})]}),!B&&(0,l.jsxs)(w.bZ,{className:"mb-4",children:[l.jsx(S.Z,{className:"h-4 w-4"}),(0,l.jsxs)(w.X,{children:["Hızlı \xf6deme i\xe7in"," ",l.jsx(s.default,{href:"/login",className:"text-slate-800 hover:underline font-semibold",children:"giriş yapın"})," ","veya"," ",l.jsx(s.default,{href:"/register",className:"text-slate-800 hover:underline font-semibold",children:"kayıt olun"}),". Hesap olmadan da ",l.jsx(s.default,{href:"/checkout",className:"text-slate-800 hover:underline font-semibold",children:"\xd6demeye Ge\xe7"})," ile sipariş verebilirsiniz."]})]}),(0,l.jsxs)("div",{className:"pt-4 border-t space-y-3",children:[(0,l.jsxs)("h4",{className:"text-sm font-semibold text-ink flex items-center gap-2",children:[l.jsx(A.Z,{className:"w-4 h-4 text-slate-600"}),"S\xf6zleşme ve Şartlar"]}),(0,l.jsxs)("label",{className:"flex items-start gap-2 cursor-pointer py-2 touch-manipulation min-h-[44px] items-center",children:[l.jsx("input",{type:"checkbox",checked:O,onChange:e=>F(e.target.checked),className:"w-5 h-5 min-w-[20px] min-h-[20px] text-slate-800 border-slate-300 rounded focus:ring-2 focus:ring-slate-400 shrink-0"}),(0,l.jsxs)("span",{className:"text-xs text-ink",children:[l.jsx("button",{type:"button",onClick:e=>{e.preventDefault(),ee("sales")},className:"font-medium text-slate-800 hover:underline text-left",children:'"Uzaktan Satış S\xf6zleşmesi"'})," ve ",l.jsx("button",{type:"button",onClick:e=>{e.preventDefault(),ee("sales")},className:"font-medium text-slate-800 hover:underline text-left",children:'"Kullanım Şartları"'}),"nı okudum ve kabul ediyorum."]})]}),(0,l.jsxs)("label",{className:"flex items-start gap-2 cursor-pointer py-2 touch-manipulation min-h-[44px] items-center",children:[l.jsx("input",{type:"checkbox",checked:W,onChange:e=>$(e.target.checked),className:"w-5 h-5 min-w-[20px] min-h-[20px] text-slate-800 border-slate-300 rounded focus:ring-2 focus:ring-slate-400 shrink-0"}),(0,l.jsxs)("span",{className:"text-xs text-ink",children:[l.jsx("button",{type:"button",onClick:e=>{e.preventDefault(),ee("privacy")},className:"font-medium text-slate-800 hover:underline text-left",children:'"Gizlilik S\xf6zleşmesi"'}),"ni okudum ve kabul ediyorum."]})]}),(0,l.jsxs)("label",{className:"flex items-start gap-2 cursor-pointer py-2 touch-manipulation min-h-[44px] items-center",children:[l.jsx("input",{type:"checkbox",checked:X,onChange:e=>Q(e.target.checked),className:"w-5 h-5 min-w-[20px] min-h-[20px] text-slate-800 border-slate-300 rounded focus:ring-2 focus:ring-slate-400 shrink-0"}),(0,l.jsxs)("span",{className:"text-xs text-ink",children:[l.jsx("button",{type:"button",onClick:e=>{e.preventDefault(),ee("kvkk")},className:"font-medium text-slate-800 hover:underline text-left",children:'"KVKK Aydınlatma Metni"'}),"ni okudum ve kabul ediyorum."]})]})]}),l.jsx(c.z,{asChild:!0,size:"lg",className:"w-full rounded-xl min-h-[48px] touch-manipulation bg-slate-800 hover:bg-slate-700 text-white",disabled:!O||!W||!X,children:(0,l.jsxs)(s.default,{href:"/checkout",className:"flex items-center justify-center gap-2",children:[l.jsx(g.Z,{className:"w-5 h-5"}),"\xd6demeye Ge\xe7"]})}),(0,l.jsxs)("div",{className:"text-xs text-slate-500 text-center space-y-1",children:[(0,l.jsxs)("div",{className:"flex items-center justify-center gap-1",children:[l.jsx(p.Z,{className:"w-3 h-3"}),l.jsx("span",{children:"G\xfcvenli \xd6deme"})]}),l.jsx("div",{children:"7/24 M\xfcşteri Desteği"})]})]})]})})]}),J&&l.jsx("div",{className:"fixed z-50 inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4",onClick:()=>ee(null),children:(0,l.jsxs)("div",{className:"bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden flex flex-col",onClick:e=>e.stopPropagation(),children:[(0,l.jsxs)("div",{className:"flex items-center justify-between p-6 border-b border-slate-200 bg-slate-50",children:[(0,l.jsxs)("h3",{className:"text-xl font-bold text-ink",children:["sales"===J&&"Uzaktan Satış S\xf6zleşmesi","privacy"===J&&"Gizlilik S\xf6zleşmesi","kvkk"===J&&"KVKK Aydınlatma Metni"]}),l.jsx("button",{className:"p-3 -mr-2 min-h-[44px] min-w-[44px] flex items-center justify-center hover:bg-muted rounded-lg transition-colors touch-manipulation",onClick:()=>ee(null),"aria-label":"Kapat",children:l.jsx("span",{className:"text-2xl text-slate-500 hover:text-slate-900",children:"\xd7"})})]}),l.jsx("div",{className:"p-6 overflow-y-auto flex-1",children:(0,l.jsxs)("div",{className:"prose prose-sm max-w-none text-ink whitespace-pre-line leading-relaxed",children:["sales"===J&&`UZAKTAN SATIŞ S\xd6ZLEŞMESİ

1. TARAFLAR

Bu Uzaktan Satış S\xf6zleşmesi ("S\xf6zleşme"), aşağıdaki taraflar arasında aşağıdaki şartlarla akdedilmiştir:

SATICI:
Batarya Kit
Web Sitesi: www.bataryakit.com
E-posta: info@revision.com

ALICI:
Bu siteden alışveriş yapan ger\xe7ek veya t\xfczel kişi m\xfcşteri.

2. KONU

Bu s\xf6zleşmenin konusu, Alıcı'nın satıcı web sitesi \xfczerinden elektronik ortamda sipariş verdiği, satıcının kataloğında yer alan ve satışa sunulan \xfcr\xfcnlerin satışı ve teslimi ile ilgili olarak 6502 sayılı T\xfcketicinin Korunması Hakkında Kanun ve Uzaktan Satış Y\xf6netmeliği h\xfck\xfcmleri gereğince tarafların hak ve y\xfck\xfcml\xfcl\xfcklerinin belirlenmesidir.

3. SİPARİŞ VE KABUL

3.1. Sitede yer alan \xfcr\xfcnlerin fiyatları ve \xf6zellikleri \xf6nceden bildirilmeksizin değiştirilebilir. Ancak sipariş verilen \xfcr\xfcn\xfcn fiyatı, sipariş anında ge\xe7erli olan fiyattır.

3.2. Sipariş, Alıcı tarafından elektronik ortamda sipariş formu doldurularak verilir. Siparişin onaylanması, Satıcı tarafından Alıcı'ya g\xf6nderilecek e-posta ile ger\xe7ekleşir.

3.3. Sipariş onayından sonra, Alıcı'ya sipariş detayları e-posta ile g\xf6nderilir.

4. FİYAT VE \xd6DEME

4.1. \xdcr\xfcn fiyatları, KDV dahil olarak g\xf6sterilir. Kargo \xfccreti, 3000 TL ve \xfczeri siparişlerde \xfccretsizdir. 3000 TL altı siparişlerde kargo \xfccreti Alıcı'ya aittir.

4.2. \xd6deme, sipariş sırasında belirtilen \xf6deme y\xf6ntemleri ile yapılır. \xd6deme onayından sonra sipariş işleme alınır.

5. TESLİMAT

5.1. \xdcr\xfcnler, Alıcı'nın sipariş formunda belirttiği adrese teslim edilir. Teslimat s\xfcresi, stok durumuna g\xf6re değişiklik g\xf6sterebilir.

5.2. Teslimat sırasında Alıcı veya temsilcisi \xfcr\xfcn\xfc kontrol etmekle y\xfck\xfcml\xfcd\xfcr. Hasarlı veya eksik \xfcr\xfcn tesliminde, kargo firmasına tutanak tutturulmalıdır.

6. CAYMA HAKKI

6.1. Alıcı, 6502 sayılı Kanun'un 15. maddesi gereğince, teslim tarihinden itibaren 14 g\xfcn i\xe7inde hi\xe7bir gerek\xe7e g\xf6stermeksizin ve cezai şart \xf6demeksizin s\xf6zleşmeden cayma hakkına sahiptir.

6.2. Cayma hakkının kullanılması i\xe7in, Alıcı'nın Satıcı'ya yazılı bildirimde bulunması veya \xfcr\xfcn\xfc iade etmesi gerekir.

6.3. İade edilecek \xfcr\xfcnler, kullanılmamış, orijinal ambalajında ve faturası ile birlikte olmalıdır.

7. GARANTİ VE YETKİLİ SERVİS

7.1. \xdcr\xfcnler, \xfcretici firmanın garanti şartlarına tabidir. Garanti s\xfcresi ve kapsamı, \xfcr\xfcn kategorisine g\xf6re değişiklik g\xf6sterebilir.

7.2. Garanti kapsamındaki arızalar i\xe7in, \xfcr\xfcn yetkili servise g\xf6nderilmelidir.

8. SORUMLULUK SINIRLAMASI

8.1. Satıcı, \xfcr\xfcnlerin kullanımından kaynaklanan doğrudan veya dolaylı zararlardan sorumlu tutulamaz.

8.2. Satıcı, \xfcr\xfcnlerin yanlış kullanımından kaynaklanan zararlardan sorumlu değildir.

9. KİŞİSEL VERİLERİN KORUNMASI

9.1. Alıcı'nın kişisel verileri, 6698 sayılı KVKK Kanunu'na uygun olarak işlenir ve korunur.

9.2. Kişisel veriler, sadece sipariş işlemleri i\xe7in kullanılır ve \xfc\xe7\xfcnc\xfc kişilerle paylaşılmaz.

10. UYUŞMAZLIKLARIN \xc7\xd6Z\xdcM\xdc

10.1. Bu s\xf6zleşmeden doğan uyuşmazlıklar, T\xfcrkiye Cumhuriyeti yasalarına tabidir.

10.2. Uyuşmazlıkların \xe7\xf6z\xfcm\xfcnde \xf6ncelikle m\xfczakere yolu tercih edilir. Anlaşmazlık durumunda, t\xfcketici hakem heyetleri ve t\xfcketici mahkemeleri yetkilidir.

11. Y\xdcR\xdcRL\xdcK

Bu s\xf6zleşme, Alıcı'nın sipariş vermesi ve Satıcı'nın siparişi onaylaması ile y\xfcr\xfcrl\xfcğe girer.

S\xf6zleşme Tarihi: ${new Date().toLocaleDateString("tr-TR")}
Satıcı: Batarya Kit`,"privacy"===J&&`GİZLİLİK POLİTİKASI

1. GENEL BİLGİLER

Bu Gizlilik Politikası, Batarya Kit ("Biz", "Bizim", "Site") olarak, www.bataryakit.com web sitesini ziyaret eden ve hizmetlerimizi kullanan kullanıcıların ("Kullanıcı", "Siz") kişisel bilgilerinin nasıl toplandığını, kullanıldığını, korunduğunu ve paylaşıldığını a\xe7ıklar.

2. TOPLANAN BİLGİLER

2.1. Kişisel Bilgiler:
- Ad, soyad
- E-posta adresi
- Telefon numarası
- Fatura ve teslimat adresi
- \xd6deme bilgileri (g\xfcvenli \xf6deme sistemleri \xfczerinden)

2.2. Otomatik Toplanan Bilgiler:
- IP adresi
- Tarayıcı t\xfcr\xfc ve versiyonu
- İşletim sistemi
- Ziyaret edilen sayfalar ve s\xfcre
- Referans URL

3. BİLGİLERİN KULLANIMI

Toplanan bilgiler aşağıdaki ama\xe7larla kullanılır:
- Sipariş işlemlerinin ger\xe7ekleştirilmesi
- M\xfcşteri hizmetleri sağlanması
- \xdcr\xfcn ve hizmetlerin iyileştirilmesi
- Yasal y\xfck\xfcml\xfcl\xfcklerin yerine getirilmesi
- Pazarlama faaliyetleri (izin verilmesi halinde)

4. BİLGİLERİN PAYLAŞIMI

4.1. Kişisel bilgileriniz, aşağıdaki durumlar dışında \xfc\xe7\xfcnc\xfc kişilerle paylaşılmaz:
- Yasal zorunluluklar
- Kargo ve \xf6deme işlemleri i\xe7in gerekli servis sağlayıcılar
- İzin verilmesi halinde pazarlama ortakları

4.2. T\xfcm \xfc\xe7\xfcnc\xfc taraf servis sağlayıcılar, verilerinizi korumakla y\xfck\xfcml\xfcd\xfcr.

5. \xc7EREZLER (COOKIES)

5.1. Sitemiz, kullanıcı deneyimini iyileştirmek i\xe7in \xe7erezler kullanır.

5.2. \xc7erez t\xfcrleri:
- Zorunlu \xe7erezler: Site işlevselliği i\xe7in gerekli
- Analitik \xe7erezler: Site kullanım istatistikleri
- Pazarlama \xe7erezleri: Kişiselleştirilmiş reklamlar

5.3. \xc7erez tercihlerinizi tarayıcı ayarlarından y\xf6netebilirsiniz.

6. VERİ G\xdcVENLİĞİ

6.1. Kişisel bilgileriniz, SSL şifreleme teknolojisi ile korunur.

6.2. \xd6deme bilgileri, PCI-DSS uyumlu g\xfcvenli \xf6deme sistemleri \xfczerinden işlenir.

6.3. Verileriniz, g\xfcvenli sunucularda saklanır ve yetkisiz erişime karşı korunur.

7. KULLANICI HAKLARI

KVKK Kanunu kapsamında aşağıdaki haklara sahipsiniz:
- Kişisel verilerinizin işlenip işlenmediğini \xf6ğrenme
- İşlenen kişisel verileriniz hakkında bilgi talep etme
- Kişisel verilerinizin d\xfczeltilmesini isteme
- Kişisel verilerinizin silinmesini isteme
- İşlenen verilerin muhafazasını talep etme
- İşlenen verilerin aktarılmasını isteme
- İşleme itiraz etme

8. VERİ SAKLAMA S\xdcRESİ

Kişisel verileriniz, yasal saklama s\xfcreleri ve işleme ama\xe7ları doğrultusunda saklanır. Bu s\xfcreler sona erdiğinde, verileriniz g\xfcvenli bir şekilde silinir veya anonimleştirilir.

9. \xdc\xc7\xdcNC\xdc TARAF BAĞLANTILAR

Sitemizde, \xfc\xe7\xfcnc\xfc taraf web sitelerine bağlantılar bulunabilir. Bu sitelerin gizlilik politikalarından biz sorumlu değiliz.

10. \xc7OCUKLARIN GİZLİLİĞİ

Hizmetlerimiz 18 yaş altındaki kişilere y\xf6nelik değildir. 18 yaş altındaki kişilerden bilerek kişisel bilgi toplamıyoruz.

11. DEĞİŞİKLİKLER

Bu Gizlilik Politikası, yasal değişiklikler veya işletme gereksinimleri doğrultusunda g\xfcncellenebilir. \xd6nemli değişiklikler, sitede duyurulur.

12. İLETİŞİM

Gizlilik politikamız hakkında sorularınız i\xe7in:
E-posta: info@revision.com
Web: www.bataryakit.com

Son G\xfcncelleme: ${new Date().toLocaleDateString("tr-TR")}`,"kvkk"===J&&`KVKK AYDINLATMA METNİ

6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") uyarınca, kişisel verilerinizin işlenmesi hakkında sizleri bilgilendirmek isteriz.

1. VERİ SORUMLUSU

Batarya Kit
Web Sitesi: www.bataryakit.com
E-posta: info@revision.com

2. İŞLENEN KİŞİSEL VERİLER

2.1. Kimlik Bilgileri:
- Ad, soyad
- T.C. Kimlik No (fatura i\xe7in gerekli olması halinde)

2.2. İletişim Bilgileri:
- E-posta adresi
- Telefon numarası
- Adres bilgileri

2.3. M\xfcşteri İşlem Bilgileri:
- Sipariş ge\xe7mişi
- \xdcr\xfcn tercihleri
- İletişim ge\xe7mişi

2.4. İşlem G\xfcvenliği Bilgileri:
- IP adresi
- \xc7erez bilgileri
- Tarayıcı bilgileri

2.5. Pazarlama Bilgileri:
- E-posta abonelik durumu
- Tercih ve beğeniler

3. KİŞİSEL VERİLERİN İŞLENME AMA\xc7LARI

Kişisel verileriniz aşağıdaki ama\xe7larla işlenmektedir:
- Sipariş işlemlerinin ger\xe7ekleştirilmesi
- \xdcr\xfcn ve hizmetlerin sunulması
- M\xfcşteri ilişkileri y\xf6netimi
- Fatura ve muhasebe işlemleri
- Yasal y\xfck\xfcml\xfcl\xfcklerin yerine getirilmesi
- Pazarlama ve tanıtım faaliyetleri (izin verilmesi halinde)
- İstatistiksel analizler
- Site g\xfcvenliğinin sağlanması

4. KİŞİSEL VERİLERİN İŞLENME HUKUKİ SEBEPLERİ

Kişisel verileriniz, KVKK'nın 5. ve 6. maddelerinde belirtilen aşağıdaki hukuki sebeplere dayanarak işlenmektedir:
- A\xe7ık rıza
- S\xf6zleşmenin kurulması veya ifası
- Yasal y\xfck\xfcml\xfcl\xfcklerin yerine getirilmesi
- Meşru menfaatler

5. KİŞİSEL VERİLERİN AKTARILMASI

Kişisel verileriniz, aşağıdaki durumlarda \xfc\xe7\xfcnc\xfc kişilere aktarılabilir:

5.1. Kargo Firmaları:
Siparişlerinizin teslimi i\xe7in kargo firmalarına adres bilgileriniz aktarılır.

5.2. \xd6deme İşlemcisi:
\xd6deme işlemlerinin ger\xe7ekleştirilmesi i\xe7in g\xfcvenli \xf6deme sistemlerine \xf6deme bilgileriniz aktarılır.

5.3. Yasal Zorunluluklar:
Yasal y\xfck\xfcml\xfcl\xfcklerin yerine getirilmesi i\xe7in ilgili kamu kurum ve kuruluşlarına bilgileriniz aktarılabilir.

5.4. Hizmet Sağlayıcılar:
Web sitesi hosting, e-posta servisleri gibi teknik hizmet sağlayıcılarına sınırlı bilgiler aktarılabilir.

6. KİŞİSEL VERİLERİNİZİN SAKLAMA S\xdcRESİ

Kişisel verileriniz, işleme ama\xe7larının gerektirdiği s\xfcre boyunca ve yasal saklama s\xfcrelerine uygun olarak saklanır:
- Sipariş bilgileri: 10 yıl (Vergi Usul Kanunu)
- M\xfcşteri iletişim kayıtları: 3 yıl
- Pazarlama izinleri: İptal edilene kadar

7. KVKK KAPSAMINDAKİ HAKLARINIZ

KVKK'nın 11. maddesi uyarınca aşağıdaki haklara sahipsiniz:

7.1. Bilgi Talep Etme:
Kişisel verilerinizin işlenip işlenmediğini \xf6ğrenme hakkı.

7.2. Erişim Hakkı:
İşlenen kişisel verileriniz hakkında bilgi talep etme hakkı.

7.3. D\xfczeltme Hakkı:
Yanlış veya eksik işlenen verilerinizin d\xfczeltilmesini isteme hakkı.

7.4. Silme Hakkı:
Kişisel verilerinizin silinmesini isteme hakkı.

7.5. İtiraz Hakkı:
Kişisel verilerinizin işlenmesine itiraz etme hakkı.

7.6. Veri Taşınabilirliği:
Kişisel verilerinizin başka bir veri sorumlusuna aktarılmasını isteme hakkı.

8. HAKLARINIZI KULLANMA Y\xd6NTEMİ

Haklarınızı kullanmak i\xe7in:
- E-posta: info@revision.com
- Web: www.bataryakit.com/iletisim

Başvurularınız, KVKK'nın 13. maddesi uyarınca en ge\xe7 30 g\xfcn i\xe7inde sonu\xe7landırılır.

9. VERİ G\xdcVENLİĞİ

Kişisel verileriniz:
- G\xfcvenli sunucularda saklanır
- SSL şifreleme ile korunur
- Yetkisiz erişime karşı korunur
- D\xfczenli olarak yedeklenir

10. \xc7EREZLER

Sitemiz, kullanıcı deneyimini iyileştirmek i\xe7in \xe7erezler kullanır. \xc7erez politikamız hakkında detaylı bilgi i\xe7in: www.bataryakit.com/cookies

11. DEĞİŞİKLİKLER

Bu aydınlatma metni, yasal değişiklikler doğrultusunda g\xfcncellenebilir. G\xfcncel versiyon sitede yayınlanır.

12. İLETİŞİM

KVKK kapsamındaki haklarınız ve kişisel verileriniz hakkında sorularınız i\xe7in:
E-posta: info@revision.com
Adres: [Şirket Adresi]

Son G\xfcncelleme: ${new Date().toLocaleDateString("tr-TR")}`]})}),l.jsx("div",{className:"p-4 border-t border-slate-200 bg-slate-50 pb-safe",children:l.jsx(c.z,{onClick:()=>ee(null),className:"w-full rounded-xl min-h-[48px] touch-manipulation bg-slate-800 hover:bg-slate-700 text-white",children:"Kapat"})})]})})]})}},43273:(e,i,a)=>{"use strict";a.d(i,{X:()=>d,bZ:()=>c});var l=a(10326),r=a(17577),s=a(79360),t=a(77863);let n=(0,s.j)("relative w-full rounded-lg border p-4 [&>svg~*]:pl-7 [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground",{variants:{variant:{default:"bg-background text-foreground",destructive:"border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive"}},defaultVariants:{variant:"default"}}),c=r.forwardRef(({className:e,variant:i,...a},r)=>l.jsx("div",{ref:r,role:"alert",className:(0,t.cn)(n({variant:i}),e),...a}));c.displayName="Alert",r.forwardRef(({className:e,...i},a)=>l.jsx("h5",{ref:a,className:(0,t.cn)("mb-1 font-medium leading-none tracking-tight",e),...i})).displayName="AlertTitle";let d=r.forwardRef(({className:e,...i},a)=>l.jsx("div",{ref:a,className:(0,t.cn)("text-sm [&_p]:leading-relaxed",e),...i}));d.displayName="AlertDescription"},33071:(e,i,a)=>{"use strict";a.d(i,{Ol:()=>n,SZ:()=>d,Zb:()=>t,aY:()=>x,ll:()=>c});var l=a(10326),r=a(17577),s=a(77863);let t=r.forwardRef(({className:e,...i},a)=>l.jsx("div",{ref:a,className:(0,s.cn)("rounded-xl border bg-card text-card-foreground shadow-md hover:shadow-lg transition-shadow",e),...i}));t.displayName="Card";let n=r.forwardRef(({className:e,...i},a)=>l.jsx("div",{ref:a,className:(0,s.cn)("flex flex-col space-y-1.5 p-6",e),...i}));n.displayName="CardHeader";let c=r.forwardRef(({className:e,...i},a)=>l.jsx("h3",{ref:a,className:(0,s.cn)("text-2xl font-semibold leading-none tracking-tight",e),...i}));c.displayName="CardTitle";let d=r.forwardRef(({className:e,...i},a)=>l.jsx("p",{ref:a,className:(0,s.cn)("text-sm text-muted-foreground",e),...i}));d.displayName="CardDescription";let x=r.forwardRef(({className:e,...i},a)=>l.jsx("div",{ref:a,className:(0,s.cn)("p-6 pt-0",e),...i}));x.displayName="CardContent",r.forwardRef(({className:e,...i},a)=>l.jsx("div",{ref:a,className:(0,s.cn)("flex items-center p-6 pt-0",e),...i})).displayName="CardFooter"},45842:(e,i,a)=>{"use strict";a.d(i,{_:()=>x});var l=a(10326),r=a(17577),s=a(45226),t=r.forwardRef((e,i)=>(0,l.jsx)(s.WV.label,{...e,ref:i,onMouseDown:i=>{i.target.closest("button, input, select, textarea")||(e.onMouseDown?.(i),!i.defaultPrevented&&i.detail>1&&i.preventDefault())}}));t.displayName="Label";var n=a(79360),c=a(77863);let d=(0,n.j)("text-base font-medium leading-snug peer-disabled:cursor-not-allowed peer-disabled:opacity-70"),x=r.forwardRef(({className:e,...i},a)=>l.jsx(t,{ref:a,className:(0,c.cn)(d(),e),...i}));x.displayName=t.displayName},68483:(e,i,a)=>{"use strict";a.d(i,{Z:()=>x});var l=a(10326),r=a(17577),s=a(45226),t="horizontal",n=["horizontal","vertical"],c=r.forwardRef((e,i)=>{let{decorative:a,orientation:r=t,...c}=e,d=n.includes(r)?r:t;return(0,l.jsx)(s.WV.div,{"data-orientation":d,...a?{role:"none"}:{"aria-orientation":"vertical"===d?d:void 0,role:"separator"},...c,ref:i})});c.displayName="Separator";var d=a(77863);let x=r.forwardRef(({className:e,orientation:i="horizontal",decorative:a=!0,...r},s)=>l.jsx(c,{ref:s,decorative:a,orientation:i,className:(0,d.cn)("shrink-0 bg-border","horizontal"===i?"h-[1px] w-full":"h-full w-[1px]",e),...r}));x.displayName=c.displayName},86333:(e,i,a)=>{"use strict";a.d(i,{Z:()=>l});let l=(0,a(76557).Z)("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]])},11019:(e,i,a)=>{"use strict";a.d(i,{Z:()=>l});let l=(0,a(76557).Z)("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]])},48705:(e,i,a)=>{"use strict";a.d(i,{Z:()=>l});let l=(0,a(76557).Z)("Package",[["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}],["path",{d:"M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z",key:"hh9hay"}],["path",{d:"m3.3 7 8.7 5 8.7-5",key:"g66t2b"}],["path",{d:"M12 22V12",key:"d0xqtd"}]])},83855:(e,i,a)=>{"use strict";a.d(i,{Z:()=>l});let l=(0,a(76557).Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},58038:(e,i,a)=>{"use strict";a.d(i,{Z:()=>l});let l=(0,a(76557).Z)("Shield",[["path",{d:"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10",key:"1irkt0"}]])},98091:(e,i,a)=>{"use strict";a.d(i,{Z:()=>l});let l=(0,a(76557).Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},56826:(e,i,a)=>{"use strict";a.r(i),a.d(i,{default:()=>l});let l=(0,a(68570).createProxy)(String.raw`C:\Users\aslan\Desktop\eticaret - Kopya\app\cart\page.tsx#default`)}};var i=require("../../webpack-runtime.js");i.C(e);var a=e=>i(i.s=e),l=i.X(0,[8948,1615,5662,6226],()=>a(46665));module.exports=l})();