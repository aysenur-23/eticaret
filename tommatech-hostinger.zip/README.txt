=========================================================
  TommaTech Türkiye — Hostinger Node.js Deployment
=========================================================

Bu klasör Hostinger'a olduğu gibi yüklenecek production build'i içerir.

---------------------------------------------------------
📤 YÜKLEME ADIMLARI
---------------------------------------------------------

1. Bu klasördeki TÜM dosyaları (gizli dosyalar dahil) FTP veya
   Hostinger File Manager ile public_html klasörüne yükleyin.
   Gizli dosyalar: .env.production  .htaccess  .next/  .env

2. Hostinger Kontrol Paneli → Websites → Manage → Node.js bölümüne gidin:
   - Node.js Version  : 20.x (veya en güncel LTS)
   - Application Root : /public_html
   - Application Startup File : server.js   ← ÖNEMLİ (index.js değil!)
   - Start butonuna tıklayın.

3. .env.production dosyasını doldurun (aşağıdaki ortam değişkenleri):
   Hostinger → Node.js → Environment Variables bölümünden de girebilirsiniz.

---------------------------------------------------------
🔑 ZORUNLU ORTAM DEĞİŞKENLERİ
---------------------------------------------------------

NEXT_PUBLIC_SITE_URL         = https://bataryakit.com
NEXT_PUBLIC_BASE_URL         = https://bataryakit.com
NEXTAUTH_URL                 = https://bataryakit.com
NEXTAUTH_SECRET              = (en az 32 karakter güçlü şifre)
JWT_SECRET                   = (en az 32 karakter güçlü şifre)
DATABASE_URL                 = file:./data/prod.db
NODE_ENV                     = production

Firebase (Firebase Console → Project Settings → Your Apps):
  NEXT_PUBLIC_FIREBASE_API_KEY
  NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN
  NEXT_PUBLIC_FIREBASE_PROJECT_ID
  NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET
  NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID
  NEXT_PUBLIC_FIREBASE_APP_ID

Firebase Admin (Firebase Console → Project Settings → Service Accounts):
  FIREBASE_ADMIN_PROJECT_ID
  FIREBASE_ADMIN_CLIENT_EMAIL
  FIREBASE_ADMIN_PRIVATE_KEY     (tırnaklarla: "-----BEGIN PRIVATE KEY-----\n...")

E-posta (birini seçin):
  Resend:  RESEND_API_KEY
  SMTP:    SMTP_HOST / SMTP_PORT / SMTP_USER / SMTP_PASSWORD

İsteğe bağlı:
  STRIPE_SECRET_KEY / STRIPE_WEBHOOK_SECRET
  PAYTR_MERCHANT_ID / PAYTR_MERCHANT_KEY / PAYTR_MERCHANT_SALT

---------------------------------------------------------
📁 KLASÖR YAPISI
---------------------------------------------------------

  server.js          → Ana uygulama (Startup File olarak ayarlayın)
  package.json       → "start": "node server.js"
  node_modules/      → Standalone build içinde bundled bağımlılıklar
  .next/             → Next.js server-side dosyaları
  _next/             → Web'den erişilebilir static assets
  public/            → Statik public dosyalar
  .htaccess          → Apache / static dosya yönlendirmesi
  .env.production    → Ortam değişkenleri şablonu (doldurun!)
  favicon.ico        → Site ikonu

---------------------------------------------------------
✅ KONTROL LİSTESİ
---------------------------------------------------------

  [ ] Tüm dosyalar (gizliler dahil) yüklendi
  [ ] .env.production dolduruldu ve kaydedildi
  [ ] Hostinger Node.js → Application Startup File: server.js
  [ ] Hostinger Node.js → Node.js Version: 20.x
  [ ] Hostinger Node.js uygulaması başlatıldı (Start)
  [ ] Domain → bataryakit.com → public_html yönlendirildi
  [ ] SSL sertifikası aktif (Hostinger → SSL)
  [ ] Site açık: https://bataryakit.com

---------------------------------------------------------
⚠️  ÖNEMLİ NOTLAR
---------------------------------------------------------

• server.js'i Hostinger'da "Node.js Application Startup File" olarak
  ayarlamazsanız site çalışmaz.

• SQLite kullanıyorsanız (DATABASE_URL=file:./data/prod.db):
  - data/ klasörü sunucuda otomatik oluşur
  - İlk çalıştırmadan önce: npx prisma migrate deploy
  - Hostinger SSH erişimi gerekebilir

• MySQL kullanıyorsanız:
  DATABASE_URL=mysql://kullanici:sifre@localhost:3306/db_adi

• Firebase private key içindeki \n karakterleri gerçek yeni satır
  değil, ters eğik çizgi + n olarak saklanır. Hostinger env variable
  olarak girerken tek satır halinde \n şeklinde yazın.

=========================================================
